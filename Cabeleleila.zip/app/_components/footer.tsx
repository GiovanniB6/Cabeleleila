"use client";

import Link from "next/link";
import { ArrowUp, Headset, Phone, Scissors } from "lucide-react";
import { MdEmail } from "react-icons/md";
import { FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa";

const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};

const Footer = () => {
  return (
    <footer className="flex flex-col">
      <div className="flex w-full flex-col justify-between bg-secondary px-5 pb-5 pt-6 lg:flex-row lg:px-32 lg:pb-9 lg:pt-5">
        <div className="flex flex-col items-start justify-center gap-5 pb-1 md:justify-start lg:pt-5">
          <Link
            href="/"
            className="flex items-center gap-1 font-bold outline-none"
          >
            <Scissors className="font-bold text-purple-500" />

            <h2 className="font-berkshire-swash md:text-lg">CABELELEILA LEILA</h2>

            <Scissors className="trasform rotate-180 font-bold text-purple-500" />
          </Link>
        </div>

        <div className="flex flex-col gap-5 pt-5 lg:flex-row lg:gap-10 lg:px-0">
          <div className="flex flex-col">
            <h3 className="md:pl-5">DEPARTAMENTOS</h3>
            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">Serviços</p>
            </div>

            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">Agendamentos</p>
            </div>

            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">Salões Recomendados</p>
            </div>
          </div>

          <div className="flex flex-col">
            <h3 className="md:pl-5">INSTITUCIONAL</h3>
            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">Sobre a CABELELEILA LEILA</p>
            </div>

            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">Termos e condições</p>
            </div>

            <div className="group flex items-center gap-1">
              <Scissors className="size-4 font-bold opacity-0 duration-200 group-hover:opacity-100" />
              <p className="text-foreground/90">
                Política de segurança e privacidade
              </p>
            </div>
          </div>

          <div className="flex flex-col">
            <h3 className="md:pl-5">CONTATO</h3>
            <div className="flex items-center gap-1">
              <Phone className="size-4 font-bold" />
              <p className="text-foreground/90">(11) 91234 5678</p>
            </div>

            <div className="flex items-center gap-1">
              <Headset className="size-4 font-bold" />
              <p className="text-foreground/90">SAC - 0800 1234 5678</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between border-t border-gray-700 bg-secondary px-5 py-5 lg:px-32">
        <div className="lg:flex lg:gap-5">
          <p className="text-sm font-bold text-foreground/90 md:text-base">
            © 2024 CABELELEILA LEILA
            <br className="md:hidden" /> Todos os direitos reservados
          </p>
        </div>

        <button
          onClick={scrollToTop}
          className="animate-bounce rounded-full border border-gray-600 p-2 outline-none"
        >
          <ArrowUp />
        </button>
      </div>
    </footer>
  );
};

export default Footer;
