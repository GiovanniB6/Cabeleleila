import { PrismaClient } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

const prisma = new PrismaClient();

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    if (!id) {
      return NextResponse.json({ message: "ID inválido" }, { status: 400 });
    }

    const booking = await prisma.booking.findUnique({
      where: {
        id: id,
      },
    });

    if (!booking) {
      return NextResponse.json({ message: "Reserva não encontrada" }, { status: 404 });
    }

    // Formate a data para ISO string
    const formattedDate = booking.date.toISOString();

    return NextResponse.json({ ...booking, date: formattedDate });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ message: "Erro ao buscar reserva" }, { status: 500 });
  }
}