interface QuickSearchOptions {
  iamgeUrl: string;
  title: string;
  disabled?: boolean;
}

export const quickSerachOptions: QuickSearchOptions[] = [
  {
    iamgeUrl: "/scissors.svg",
    title: "Corte Feminino",
    disabled: true
  },
  {
    iamgeUrl: "/depilationf.svg",
    title: "Depilação Facial",
    disabled: true
  },
  {
    iamgeUrl: "/depilation.svg",
    title: "Depilação Corporal",
    disabled: true
  },
  {
    iamgeUrl: "/eyebrow-fill.svg",
    title: "Design de Sobrancelhas",
    disabled: true
  },
  {
    iamgeUrl: "/massage.svg",
    title: "Massagem Relaxante",
    disabled: true
  },
  {
    iamgeUrl: "/hydration.svg",
    title: "Tratamento Capilar",
    disabled: true
  },
];
