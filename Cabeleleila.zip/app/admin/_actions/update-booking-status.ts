"use server";

import { db } from "@/app/_lib/prisma";
import { revalidatePath } from "next/cache";

export const updateBookingStatus = async (bookingId: string, status: string) => {
  await db.booking.update({
    where: {
      id: bookingId,
    },
    data: {
      status,
    },
  });

  revalidatePath("/admin");
  revalidatePath("/bookings");
}; 