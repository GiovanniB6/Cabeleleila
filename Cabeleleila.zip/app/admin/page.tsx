import { db } from "@/app/_lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/_lib/auth";
import { redirect } from "next/navigation";
import AdminBookingsList from "./_components/admin-bookings-list";

const AdminPage = async () => {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/");
  }

  // Verifica se o usuário é administrador
  const userAccount = await db.account.findFirst({
    where: {
      userId: (session.user as any).id,
    },
  });

  if (!userAccount?.isAdmin) {
    redirect("/");
  }

  // Busca todos os agendamentos
  const bookings = await db.booking.findMany({
    include: {
      Service: true,
      barbershop: true,
      user: true,
    },
    orderBy: {
      date: "asc",
    },
  });

  return (
    <div className="container mx-auto p-6">
      <h1 className="mb-8 text-3xl font-bold">Painel Administrativo</h1>
      
      <div className="mb-8">
        <h2 className="mb-4 text-2xl font-semibold">Agendamentos</h2>
        <AdminBookingsList bookings={bookings} />
      </div>
    </div>
  );
};

export default AdminPage; 