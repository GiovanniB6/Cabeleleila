"use server";

import { authOptions } from "@/app/_lib/auth";
import { db } from "@/app/_lib/prisma";
import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { startOfWeek, endOfWeek, addDays, isWithinInterval } from "date-fns";

interface SaveBookingParams {
  barbershopId: string;
  serviceId: string;
  userId: string;
  date: Date;
}

export const saveBooking = async (params: SaveBookingParams) => {
  const user = await getServerSession(authOptions);

  if (!user) {
    throw new Error("Usuario não autentícado");
  }

  // Verifica se já existe algum agendamento nos próximos 7 dias
  const today = new Date();
  const sevenDaysFromNow = addDays(today, 7);

  const existingBookings = await db.booking.findMany({
    where: {
      userId: params.userId,
      date: {
        gte: today,
        lte: sevenDaysFromNow,
      },
    },
  });

  if (existingBookings.length > 0) {
    // Se já existe um agendamento nos próximos 7 dias, sugere agendar no mesmo dia
    const firstBooking = existingBookings[0];
    const isSameDay = firstBooking.date.toDateString() === params.date.toDateString();
    
    if (!isSameDay) {
      const formattedDate = firstBooking.date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
      
      throw new Error(`Você já tem um agendamento nos próximos 7 dias. Que tal aproveitar para fazer todos os serviços no mesmo dia (${formattedDate})?`);
    }
  }

  await db.booking.create({
    data: {
      serviceId: params.serviceId,
      userId: params.userId,
      date: params.date,
      barbershopId: params.barbershopId,
    },
  });

  revalidatePath("/");
  revalidatePath("/bookings");
};
