"use server"

import { db } from "@/app/_lib/prisma"
import { startOfWeek, endOfWeek } from "date-fns"

export const getWeekBookings = async (userId: string, date: Date, barbershopId: string) => {        
    const weekStart = startOfWeek(date, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(date, { weekStartsOn: 1 });   


    const bookings = await db.booking.findMany({
        where: {
            userId,
            date: {
                gte: weekStart,
                lte: weekEnd,
            },
            id: barbershopId,
        },
        include: {
            Service: true,
            barbershop: true,
        },
    });

    return bookings;
} 