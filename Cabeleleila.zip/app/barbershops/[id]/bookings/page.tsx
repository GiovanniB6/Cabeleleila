import { db } from "@/app/_lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/_lib/auth";
import { redirect } from "next/navigation";
import { BarbershopBookingsList } from "../_components/barbershop-bookings-list";

interface BarbershopBookingsPageProps {
  params: {
    id: string;
  };
}

const BarbershopBookingsPage = async ({ params }: BarbershopBookingsPageProps) => {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/");
  }

  const barbershop = await db.barbershop.findUnique({
    where: {
      id: params.id,
      userId: session.user.id,
    },
  });

  if (!barbershop) {
    redirect("/");
  }

  const bookings = await db.booking.findMany({
    where: {
      barbershopId: params.id,
    },
    include: {
      Service: true,
      user: true,
    },
    orderBy: {
      date: "asc",
    },
  });

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Agendamentos</h1>
      <BarbershopBookingsList bookings={bookings} />
    </div>
  );
};

export default BarbershopBookingsPage; 