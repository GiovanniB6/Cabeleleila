"use client";

import { Booking, Service, User } from "@prisma/client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/app/_components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/_components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/_components/ui/select";
import { updateBookingStatus } from "@/app/admin/_actions/update-booking-status";
import { cancelBooking } from "@/app/_actions/cancel-booking";

interface BarbershopBookingsListProps {
  bookings: (Booking & {
    Service: Service;
    user: User;
  })[];
}

const BarbershopBookingsList = ({ bookings }: BarbershopBookingsListProps) => {
  const [loading, setLoading] = useState<string | null>(null);

  const handleStatusChange = async (bookingId: string, newStatus: string) => {
    setLoading(bookingId);
    try {
      await updateBookingStatus(bookingId, newStatus);
      toast.success("Status atualizado com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar status");
    } finally {
      setLoading(null);
    }
  };

  const handleCancelBooking = async (bookingId: string) => {
    setLoading(bookingId);
    try {
      await cancelBooking(bookingId);
      toast.success("Agendamento cancelado com sucesso!");
    } catch (error) {
      toast.error("Erro ao cancelar agendamento");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Cliente</TableHead>
            <TableHead>Serviço</TableHead>
            <TableHead>Data</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {bookings.map((booking) => (
            <TableRow key={booking.id}>
              <TableCell>{booking.user.name}</TableCell>
              <TableCell>{booking.Service.name}</TableCell>
              <TableCell>
                {format(booking.date, "dd 'de' MMMM 'às' HH:mm", {
                  locale: ptBR,
                })}
              </TableCell>
              <TableCell>
                <Select
                  defaultValue={booking.status}
                  onValueChange={(value) => handleStatusChange(booking.id, value)}
                  disabled={loading === booking.id}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PENDING">Pendente</SelectItem>
                    <SelectItem value="CONFIRMED">Confirmado</SelectItem>
                    <SelectItem value="COMPLETED">Concluído</SelectItem>
                    <SelectItem value="CANCELLED">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </TableCell>
              <TableCell>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleCancelBooking(booking.id)}
                  disabled={loading === booking.id || booking.status === "CANCELLED"}
                >
                  Cancelar
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default BarbershopBookingsList; 