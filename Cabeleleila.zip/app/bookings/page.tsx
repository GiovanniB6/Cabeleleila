import { db } from "../_lib/prisma";
import { authOptions } from "../_lib/auth";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Header from "../_components/header";
import BookingItem from "../_components/booking-item";
import { Annoyed } from "lucide-react";

import { Prisma, Decimal } from "@prisma/client";

interface BookingWithServiceAndBarbershop extends Prisma.BookingGetPayload<{
  include: {
    Service: true;
    barbershop: true;
  };
}> {
  Service: {
    price: number | Decimal;
  };
}

interface BookingsPageProps {
  confirmedBookings: BookingWithServiceAndBarbershop[];
  finishedBookings: BookingWithServiceAndBarbershop[];
}

const BookingsPage = async () => {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return redirect("/");
  }

  const [confirmedBookings, finishedBookings] = await Promise.all([
    db.booking.findMany({
      where: {
        userId: (session.user as any).id,
        date: {
          gte: new Date(),
        },
      },
      include: {
        Service: true,
        barbershop: true,
      },
    }),
    db.booking.findMany({
      where: {
        userId: (session.user as any).id,
        date: {
          lt: new Date(),
        },
      },
      include: {
        Service: true,
        barbershop: true,
      },
    }),
  ]);

  // Converta o objeto Decimal para um número antes de passar para o componente cliente
  const serializedConfirmedBookings: BookingWithServiceAndBarbershop[] = confirmedBookings.map((booking) => ({
    ...booking,
    Service: {
      ...booking.Service,
      price: booking.Service.price.toNumber(),
    },
  }));

  const serializedFinishedBookings: BookingWithServiceAndBarbershop[] = finishedBookings.map((booking) => ({
    ...booking,
    Service: {
      ...booking.Service,
      price: booking.Service.price.toNumber(),
    },
  }));

  return (
    <div>
      <Header />

      <div className="flex flex-col gap-8 p-8">
        <h1 className="text-2xl font-bold">Minhas Agendas</h1>

        {serializedConfirmedBookings.length > 0 ? (
          <div className="flex flex-col gap-4">
            <h2 className="text-xl font-bold">Agendamentos Confirmados</h2>
            {serializedConfirmedBookings.map((booking) => (
              <BookingItem key={booking.id} booking={booking} />
            ))}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Annoyed />
            Nenhum agendamento confirmado
          </div>
        )}

        {serializedFinishedBookings.length > 0 ? (
          <div className="flex flex-col gap-4">
            <h2 className="text-xl font-bold">Agendamentos Finalizados</h2>
            {serializedFinishedBookings.map((booking) => (
              <BookingItem key={booking.id} booking={booking} />
            ))}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Annoyed />
            Nenhum agendamento finalizado
          </div>
        )}
      </div>
    </div>
  );
};

export default BookingsPage;