import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Substitua este email pelo email do usuário que você quer tornar admin
  const userEmail = "seu.email@exemplo.com";

  const user = await prisma.user.findUnique({
    where: {
      email: userEmail,
    },
  });

  if (!user) {
    console.error("Usuário não encontrado!");
    return;
  }

  await prisma.account.updateMany({
    where: {
      userId: user.id,
    },
    data: {
      isAdmin: true,
    },
  });

  console.log(`Usuário ${userEmail} agora é administrador!`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  }); 