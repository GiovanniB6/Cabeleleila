import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function seedDatabase() {
  try {

    const barberUser = await prisma.user.create({
      data: {
        name: "Dona do Salão",
        email: "dona@cabeleilaleila.com",
        accounts: {
          create: {
            type: "credentials",
            provider: "credentials",
            providerAccountId: "barber",
            isAdmin: false,
          },
        },
      },
    });

    const creativeNames = [
      "Cabeleleila Estilo & Glamour",
      "Cabeleleila Beleza Total",
      "Cabeleleila Hair Studio",
      "Cabeleleila Salon & Spa",
      "Cabeleleila Make & Hair",
      "Cabeleleila Beauty House",
      "Cabeleleila Hair & Fashion",
      "Cabeleleila Estilo Exclusivo",
      "Cabeleleila Studio de Beleza",
      "Cabeleleila Transformação Capilar",
    ];

    const addresses = [
      "Rua das Madeixas, 123",
      "Avenida das Tesouras, 456",
      "Praça do Glamour, 789",
      "Travessa dos Penteados, 101",
      "Alameda da Beleza, 202",
      "Estrada dos Cortes, 303",
      "Avenida da Elegância, 404",
      "Praça do Estilo, 505",
      "Rua da Transformação, 606",
      "Avenida da Moda, 707",
    ];

    const images = [
      "https://imgur.com/bfCBTWY.png",
      "https://imgur.com/ErD2NdQ.png",
      "https://imgur.com/31nBEUK.png",
      "https://imgur.com/bfCBTWY.png",
      "https://imgur.com/ErD2NdQ.png",
      "https://imgur.com/31nBEUK.png",
      "https://imgur.com/bfCBTWY.png",
      "https://imgur.com/ErD2NdQ.png",
      "https://imgur.com/31nBEUK.png",
      "https://imgur.com/bfCBTWY.png",
    ];

    const stars = [
      "500",
      "477",
      "480",
      "466",
      "491",
      "750",
      "810",
      "600",
      "590",
      "546",
    ];

    const ratings = [
      "5.0",
      "4.7",
      "4.8",
      "4.6",
      "4.9",
      "4.5",
      "5.0",
      "4.9",
      "4.7",
      "4.8",
    ];

    const descriptions = [
      "Oferecemos cortes de cabelo e penteados com um toque nostálgico, combinando técnicas clássicas com um ambiente vintage e acolhedor.",
      "Especializada em cortes de cabelo e estilos modernos, proporcionando uma experiência personalizada para cada cliente.",
      "Concentra-se em serviços de cuidados capilares, com ênfase em hidratação, corte e coloração personalizada.",
      "Um salão refinado que oferece cortes de cabelo e tratamentos com um toque de elegância e sofisticação.",
      "Um destino completo para cuidados com o cabelo, proporcionando uma variedade de serviços modernos e personalizados.",
      "Um salão com uma abordagem única, combinando a habilidade artesanal com precisão e inovação.",
      "Focada em proporcionar uma experiência de beleza de luxo, com serviços premium e tratamentos exclusivos.",
      "Especializada em transformar a aparência dos clientes, oferecendo serviços de alta qualidade e tendências atuais.",
      "Inspirada na vibração da cidade, oferece cortes e penteados com um toque urbano e moderno.",
      "Retorna às raízes da tradição da beleza, oferecendo serviços clássicos e atemporais com um toque contemporâneo.",
    ];

    const services = [
      {
        name: "Corte Feminino",
        description: "Corte personalizado com as últimas tendências femininas.",
        price: 60.0,
        imageUrl: "",
      },
      {
        name: "Depilação Facial",
        description: "Remoção de pelos com cera ou linha, deixando a pele suave e hidratada.",
        price: 40.0,
        imageUrl: "",
      },
      {
        name: "Depilação Corporal",
        description: "Depilação completa das pernas com cera quente ou fria.",
        price: 35.0,
        imageUrl: "",
      },
      {
        name: "Design de Sobrancelhas",
        description: "Design de sobrancelhas com linha ou cera, realçando seu olhar.",
        price: 20.0,
        imageUrl: "",
      },
      {
        name: "Massagem Relaxante",
        description: "Massagem relaxante com óleos essenciais e aromaterapia.",
        price: 50.0,
        imageUrl: "",
      },
      {
        name: "Tratamento Capilar",
        description: "Tratamento de hidratação profunda com produtos específicos para seu tipo de cabelo.",
        price: 25.0,
        imageUrl: "",
      },
    ];

    for (let i = 0; i < 10; i++) {
      const barbershop = await prisma.barbershop.create({
        data: {
          name: creativeNames[i],
          address: addresses[i],
          imageUrl: images[i],
          description: descriptions[i],
          ratings: ratings[i],
          stars: stars[i],
          userId: barberUser.id
        },
      });


      for (const service of services) {
        await prisma.service.create({
          data: {
            name: service.name,
            description: service.description,
            price: service.price,
            barbershopId: barbershop.id,
            imageUrl: service.imageUrl,
          },
        });
      }
    }

    console.log("Banco de dados populado com sucesso!");
  } catch (error) {
    console.error("Erro ao criar as salões:", error);
  } finally {
    await prisma.$disconnect();
  }
}

seedDatabase();
